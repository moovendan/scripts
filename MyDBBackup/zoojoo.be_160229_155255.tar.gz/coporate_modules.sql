INSERT INTO `coporate_modules` (`id`, `module_id`, `corporate_id`, `status`) VALUES (1,1,1,1),(2,1,4,1),(3,1,5,1),(4,2,1,1),(5,2,2,1);
