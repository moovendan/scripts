-- MySQL dump 10.13  Distrib 5.6.27, for osx10.10 (x86_64)
--
-- Host: aa1bsfjg63jpayb.c287deoikxyl.ap-southeast-1.rds.amazonaws.com    Database: zoojoo.be
-- ------------------------------------------------------
-- Server version	5.5.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_dare`
--

DROP TABLE IF EXISTS `admin_dare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_dare` (
  `admin_dare_id` int(11) NOT NULL AUTO_INCREMENT,
  `my_dare_id` int(11) NOT NULL,
  `my_pride_id` int(11) NOT NULL,
  `dare_text` varchar(100) NOT NULL,
  `dare_pride` varchar(100) NOT NULL,
  `display_from` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`admin_dare_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_stream`
--

DROP TABLE IF EXISTS `admin_stream`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_stream` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `corporate_id` int(11) NOT NULL,
  `story` varchar(250) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '0',
  `ignore_limits` tinyint(1) NOT NULL DEFAULT '0',
  `is_private_key` tinyint(1) NOT NULL DEFAULT '0',
  `ip_addresses` text,
  `date_created` datetime NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key` (`key`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `api_logs`
--

DROP TABLE IF EXISTS `api_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `method` varchar(6) NOT NULL,
  `params` text,
  `api_key` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `time` int(11) NOT NULL,
  `authorized` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5466 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `apps`
--

DROP TABLE IF EXISTS `apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `app_provider` varchar(100) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `sync_method` varchar(200) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `badges`
--

DROP TABLE IF EXISTS `badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges` (
  `badge_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `badge_name` varchar(50) NOT NULL,
  `badge_criteria` varchar(50) NOT NULL,
  `badge_image` varchar(50) NOT NULL,
  `badge_type` varchar(50) NOT NULL,
  `level_break_point` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `show_popup` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`badge_id`),
  KEY `badge_type` (`badge_type`,`level_break_point`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cause_order`
--

DROP TABLE IF EXISTS `cause_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cause_order` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `corp_cause_id` int(11) DEFAULT NULL,
  `corp_id` int(11) DEFAULT NULL,
  `order_status` tinyint(4) DEFAULT NULL COMMENT '1:success,4:failed,3:pending(only storing the record  in db and not pinging rangde),2:deleted,0:inactive',
  `order_attempt` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `break_point_id` int(11) unsigned DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `comments` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cause_statistics`
--

DROP TABLE IF EXISTS `cause_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cause_statistics` (
  `cause_stats_id` int(11) NOT NULL AUTO_INCREMENT,
  `cause_id` int(11) NOT NULL,
  `cause_corp_id` int(11) NOT NULL,
  `users_cnt` int(11) NOT NULL,
  `avg_Contribution` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `life_points` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `completed_date` date NOT NULL,
  `contributed_Points` int(11) NOT NULL,
  PRIMARY KEY (`cause_stats_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `causes`
--

DROP TABLE IF EXISTS `causes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `causes` (
  `cause_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cause_name` varchar(200) DEFAULT NULL,
  `bActivity` varchar(150) DEFAULT NULL,
  `cause_desc` text,
  `cause_image` varchar(250) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `cause_city` varchar(100) DEFAULT NULL,
  `cause_small_image` varchar(250) DEFAULT NULL,
  `cause_state` varchar(100) DEFAULT NULL,
  `cause_loanamount` int(11) unsigned DEFAULT NULL,
  `cause_loan_id` int(11) unsigned DEFAULT NULL,
  `cause_loan_needed` int(11) unsigned DEFAULT NULL,
  `cause_loan_raised` int(11) unsigned DEFAULT NULL,
  `cause_loan_url` varchar(250) NOT NULL,
  `cause_end_date` datetime DEFAULT NULL,
  `cause_status` tinyint(4) DEFAULT '1' COMMENT '1:active,0:inactive,2:delete,3:is ready to add to next corporate',
  `last_checked_date` datetime DEFAULT NULL,
  `timeLeft` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cause_id`),
  KEY `cause_loan_id` (`cause_loan_id`,`cause_loan_needed`,`cause_end_date`,`cause_status`,`last_checked_date`)
) ENGINE=InnoDB AUTO_INCREMENT=739 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_aq_info_answers`
--

DROP TABLE IF EXISTS `challenge_aq_info_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_aq_info_answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aq_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `weight` tinyint(2) DEFAULT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_aq_main`
--

DROP TABLE IF EXISTS `challenge_aq_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_aq_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `weight` tinyint(2) DEFAULT '1',
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_category`
--

DROP TABLE IF EXISTS `challenge_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `cat_type` enum('1','2','3') DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `weight` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_type` (`cat_type`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_info_algorithm`
--

DROP TABLE IF EXISTS `challenge_info_algorithm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_info_algorithm` (
  `algorithm_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `headline_txt` varchar(100) DEFAULT NULL,
  `serving_txt` varchar(200) DEFAULT NULL,
  `serving_input` tinyint(1) DEFAULT NULL,
  `serving_method` tinyint(1) DEFAULT NULL,
  `algorithm_case` varchar(25) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`algorithm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_info_tips`
--

DROP TABLE IF EXISTS `challenge_info_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_info_tips` (
  `info_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) unsigned DEFAULT NULL,
  `info_type` tinyint(1) DEFAULT NULL,
  `info_tip` varchar(150) DEFAULT NULL,
  `info_explanation` text,
  `info_status` tinyint(2) DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`info_id`),
  KEY `challenge_id` (`challenge_id`,`info_type`,`info_status`)
) ENGINE=InnoDB AUTO_INCREMENT=604 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_info_tips_recommended`
--

DROP TABLE IF EXISTS `challenge_info_tips_recommended`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_info_tips_recommended` (
  `recommended_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) unsigned NOT NULL,
  `info_id` int(11) DEFAULT NULL,
  `recommended_created_on` datetime DEFAULT NULL,
  `recommended_status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`recommended_id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_main`
--

DROP TABLE IF EXISTS `challenge_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_main` (
  `cha_id` int(11) NOT NULL AUTO_INCREMENT,
  `cha_name` varchar(255) NOT NULL,
  `parameter1` int(3) DEFAULT '0',
  `parameter1_min` int(3) DEFAULT '1',
  `parameter1_max` int(3) DEFAULT NULL,
  `parameter1_txt` varchar(150) DEFAULT NULL,
  `parameter1_unit` varchar(20) DEFAULT NULL,
  `parameter2` int(3) NOT NULL DEFAULT '4',
  `parameter2_min` int(3) DEFAULT '1',
  `parameter2_max` int(3) DEFAULT '7',
  `parameter2_uint` varchar(20) DEFAULT 'day',
  `parameter2_txt` varchar(150) DEFAULT NULL,
  `txt_updation` mediumtext,
  `txt_info` mediumtext,
  `txt_hover` varchar(255) NOT NULL,
  `txt_box` varchar(255) NOT NULL,
  `image_path` varchar(100) DEFAULT 'default.png',
  `twitter_key_words` varchar(150) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `status` tinyint(2) DEFAULT '1',
  `created_by` int(10) unsigned DEFAULT NULL,
  `view_status` tinyint(2) DEFAULT '1' COMMENT '1: Public, 0:private',
  PRIMARY KEY (`cha_id`),
  FULLTEXT KEY `cha_name_fulltext` (`cha_name`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_map`
--

DROP TABLE IF EXISTS `challenge_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_map` (
  `cha_id` int(11) NOT NULL,
  `cha_cat_id` int(11) NOT NULL,
  `weight` tinyint(4) DEFAULT '99',
  KEY `cha_cat_id` (`cha_cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_products_map`
--

DROP TABLE IF EXISTS `challenge_products_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_products_map` (
  `cha_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `weight` tinyint(4) DEFAULT '99',
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `challenge_targets`
--

DROP TABLE IF EXISTS `challenge_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_targets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `point_category` varchar(25) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `duration` int(3) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `weight` tinyint(4) DEFAULT NULL,
  `max_value` int(5) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `city_id` smallint(1) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` smallint(1) unsigned NOT NULL DEFAULT '1',
  `state_id` smallint(1) DEFAULT NULL,
  `city_name` char(64) DEFAULT NULL,
  `ordering` int(2) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `coporate_modules`
--

DROP TABLE IF EXISTS `coporate_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coporate_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `corporate_id` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `corporate`
--

DROP TABLE IF EXISTS `corporate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corporate` (
  `corp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `corp_name` varchar(150) DEFAULT NULL,
  `corp_address` varchar(255) DEFAULT NULL,
  `corp_state` smallint(4) unsigned DEFAULT NULL,
  `corp_city` int(6) unsigned DEFAULT NULL,
  `corp_image` varchar(100) DEFAULT NULL,
  `corp_created_on` datetime DEFAULT NULL,
  `corp_status` tinyint(2) DEFAULT '1',
  `corp_website` varchar(150) DEFAULT NULL,
  `corp_country` int(5) DEFAULT NULL,
  `corp_points` int(11) DEFAULT NULL,
  `avg_contri_per_week` int(5) DEFAULT NULL,
  `corp_pledge` int(4) DEFAULT NULL,
  `corp_email_domains` text NOT NULL,
  `cost_per_employee` decimal(5,2) DEFAULT NULL COMMENT 'max value 999.99',
  `no_of_employees` int(11) NOT NULL,
  `subdomain` varchar(100) NOT NULL,
  `email_from_name` varchar(100) NOT NULL DEFAULT 'zoojoo.BE',
  PRIMARY KEY (`corp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `corporate_causes`
--

DROP TABLE IF EXISTS `corporate_causes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corporate_causes` (
  `corp_cause_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `corporate_id` int(11) DEFAULT NULL,
  `cause_id` int(11) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `life_points` bigint(20) unsigned NOT NULL,
  `completed` tinyint(2) DEFAULT '0',
  `investment_break_point` int(11) DEFAULT NULL,
  `completed_on` datetime NOT NULL,
  `avg_contri_per_week` int(5) DEFAULT NULL,
  `cost_per_employee` decimal(5,2) DEFAULT NULL COMMENT 'max value 999.99',
  PRIMARY KEY (`corp_cause_id`),
  KEY `corporate_id` (`corporate_id`,`cause_id`,`life_points`,`investment_break_point`,`avg_contri_per_week`,`cost_per_employee`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `corporate_events`
--

DROP TABLE IF EXISTS `corporate_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corporate_events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `corporate_id` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `max_counter_value` int(11) DEFAULT NULL,
  `tip_text` text,
  `send_report` enum('0','1') DEFAULT '0',
  `completed_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` enum('0','1','2','4') DEFAULT NULL COMMENT '0-inactive,1-active,2-deleted,4-completed',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `corporate_meta`
--

DROP TABLE IF EXISTS `corporate_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corporate_meta` (
  `meta_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `corporate_id` int(11) unsigned DEFAULT NULL,
  `meta_key` varchar(100) DEFAULT NULL,
  `meta_value` varchar(200) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `corporate_user`
--

DROP TABLE IF EXISTS `corporate_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corporate_user` (
  `user_id` int(11) unsigned NOT NULL,
  `corporate_id` int(11) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `country_id` smallint(1) unsigned NOT NULL AUTO_INCREMENT,
  `country_name` char(64) DEFAULT NULL,
  `country_3_code` char(3) DEFAULT NULL,
  `country_2_code` char(2) DEFAULT NULL,
  `ordering` int(2) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `csv_list`
--

DROP TABLE IF EXISTS `csv_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csv_list` (
  `csv_id` int(11) NOT NULL AUTO_INCREMENT,
  `csv_name` varchar(100) DEFAULT NULL,
  `csv_upload_date` date NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `csv_orig_name` varchar(50) NOT NULL,
  PRIMARY KEY (`csv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dare_content`
--

DROP TABLE IF EXISTS `dare_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dare_content` (
  `cont_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cont_type` enum('my_dares','my_prides') DEFAULT NULL,
  `cont_text` varchar(250) DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `weight` int(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`cont_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `default_profile_pic`
--

DROP TABLE IF EXISTS `default_profile_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_profile_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gender` int(11) NOT NULL,
  `image_name` varchar(25) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emails`
--

DROP TABLE IF EXISTS `emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emails` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `email_hash` varchar(200) NOT NULL,
  `email_subject` varchar(250) DEFAULT NULL,
  `email_body_alt` text,
  `email_from` varchar(100) DEFAULT NULL,
  `email_from_name` varchar(150) NOT NULL,
  `email_to` varchar(100) DEFAULT NULL,
  `email_variables` text,
  `email_for` varchar(100) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `email_open` tinyint(4) NOT NULL DEFAULT '0',
  `messge_response_id` varchar(200) DEFAULT NULL,
  `sent` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'checking mail is sent or not',
  `priority` enum('1','2','3') NOT NULL COMMENT '1:high 2:medium, 3:low',
  `template` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17796 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `corporate_id` int(11) DEFAULT NULL,
  `feedback` varchar(100) NOT NULL,
  `created_on` datetime NOT NULL,
  `feedback_for` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hi5_activities`
--

DROP TABLE IF EXISTS `hi5_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hi5_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id_for` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity_action` varchar(30) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invite_friends`
--

DROP TABLE IF EXISTS `invite_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invited_from` int(11) NOT NULL,
  `invited_to` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_schedule`
--

DROP TABLE IF EXISTS `job_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_schedule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_path` tinytext,
  `module_method` tinytext,
  `params` text,
  `status` varchar(20) DEFAULT '0',
  `scheduled_at` datetime DEFAULT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `AppStatus` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=574 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `level_main`
--

DROP TABLE IF EXISTS `level_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level_main` (
  `level_id` int(11) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(255) NOT NULL,
  `avatar_male_img` varchar(255) DEFAULT NULL,
  `avatar_female_img` varchar(255) DEFAULT NULL,
  `race_id` int(11) DEFAULT NULL,
  `req_missions` int(2) DEFAULT NULL,
  `level_status` int(11) NOT NULL,
  `level_num` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `errno` int(2) NOT NULL,
  `errtype` varchar(32) NOT NULL,
  `errstr` text NOT NULL,
  `errfile` varchar(255) NOT NULL,
  `errline` int(4) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `menu_id` int(5) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) DEFAULT NULL,
  `menu_link` varchar(200) DEFAULT NULL,
  `menu_display` varchar(100) DEFAULT NULL,
  `parent_id` int(5) DEFAULT NULL,
  `class` varchar(20) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mission_names`
--

DROP TABLE IF EXISTS `mission_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mission_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `module_menus`
--

DROP TABLE IF EXISTS `module_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `menu` varchar(100) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `display_name` varchar(30) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mood_cue`
--

DROP TABLE IF EXISTS `mood_cue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mood_cue` (
  `moode_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `good` varchar(150) DEFAULT NULL,
  `bad` varchar(150) DEFAULT NULL,
  `show_on` datetime DEFAULT NULL,
  `show_end` datetime DEFAULT NULL,
  `created_by` int(11) unsigned NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`moode_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `content` varchar(500) NOT NULL,
  `corporate_id` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `perm_key` varchar(100) NOT NULL,
  `perm_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `points_category`
--

DROP TABLE IF EXISTS `points_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `points_category` (
  `point_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `point_module` varchar(20) DEFAULT NULL,
  `point_action` varchar(20) DEFAULT NULL,
  `point_cat_name` varchar(25) DEFAULT NULL,
  `point_cat_status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`point_cat_id`),
  KEY `point_cat_name` (`point_cat_name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `points_main`
--

DROP TABLE IF EXISTS `points_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `points_main` (
  `point_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `point_cat_id` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `point_status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`point_id`),
  KEY `group_id` (`group_id`,`point_cat_id`,`point_status`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `popup`
--

DROP TABLE IF EXISTS `popup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `popup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `popup_key` varchar(30) NOT NULL,
  `data` text,
  `created_on` datetime DEFAULT NULL,
  `email_sent` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `power_ups`
--

DROP TABLE IF EXISTS `power_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `power_ups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `is_public` tinyint(2) NOT NULL DEFAULT '1',
  `resilience` varchar(200) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` text,
  `actual_price` decimal(10,2) DEFAULT NULL COMMENT 'actual price',
  `discount` tinyint(4) DEFAULT NULL COMMENT 'value in %, 5 or 10',
  `coupon_code` varchar(25) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `race_main`
--

DROP TABLE IF EXISTS `race_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `race_main` (
  `race_id` int(11) NOT NULL AUTO_INCREMENT,
  `race_male_name` varchar(100) NOT NULL,
  `race_female_name` varchar(100) DEFAULT NULL,
  `race_male_img` varchar(100) DEFAULT NULL,
  `race_female_img` varchar(100) DEFAULT NULL,
  `race_male_desc` varchar(200) DEFAULT NULL,
  `race_female_desc` varchar(200) DEFAULT NULL,
  `race_status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`race_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relax`
--

DROP TABLE IF EXISTS `relax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relax` (
  `relax_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `relax_time` int(3) DEFAULT NULL,
  `relax_points` int(3) DEFAULT NULL,
  `relax_audio` varchar(100) DEFAULT NULL,
  `relax_session` varchar(100) DEFAULT NULL,
  `relax_status` tinyint(2) DEFAULT '1',
  `default_relax` tinyint(4) DEFAULT NULL,
  `order_by` int(11) NOT NULL,
  PRIMARY KEY (`relax_id`),
  KEY `relax_session` (`relax_session`,`relax_status`,`default_relax`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relax_themes`
--

DROP TABLE IF EXISTS `relax_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relax_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `theme_name` varchar(50) NOT NULL,
  `theme_audio` varchar(50) NOT NULL,
  `theme_image` varchar(50) NOT NULL,
  `theme_status` tinyint(2) NOT NULL DEFAULT '1',
  `default_theme` tinyint(4) DEFAULT NULL,
  `order_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resilience`
--

DROP TABLE IF EXISTS `resilience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resilience` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rewards`
--

DROP TABLE IF EXISTS `rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rewards` (
  `reward_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `corp_id` int(11) NOT NULL,
  `reward_name` varchar(50) NOT NULL,
  `reward_type` varchar(100) NOT NULL,
  `reward_desc` varchar(200) NOT NULL,
  `points_req` int(11) NOT NULL,
  `redeem_img` varchar(100) NOT NULL,
  `available_stock` int(11) NOT NULL,
  `minutes` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `created_by` tinyint(2) NOT NULL,
  PRIMARY KEY (`reward_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_perms`
--

DROP TABLE IF EXISTS `role_perms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_perms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `perm_id` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_demo`
--

DROP TABLE IF EXISTS `schedule_demo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_demo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `company` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `created_on` datetime NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `info` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `state_id` smallint(2) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` smallint(1) unsigned NOT NULL,
  `state_name` char(64) DEFAULT NULL,
  `state_3_code` char(3) DEFAULT NULL,
  `state_2_code` char(2) DEFAULT NULL,
  `ordering` int(2) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=554 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `statistics`
--

DROP TABLE IF EXISTS `statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statistics` (
  `stat_id` int(11) NOT NULL AUTO_INCREMENT,
  `corp_id` int(11) NOT NULL,
  `stat_period` date DEFAULT NULL,
  `stat_engagement` decimal(10,2) DEFAULT NULL,
  `stat_login` decimal(10,2) DEFAULT NULL,
  `stat_active_challengese` double(10,2) NOT NULL,
  `stat_relax` decimal(10,2) DEFAULT NULL,
  `No_of_Challenges_per_user` int(11) NOT NULL,
  `Minutes_of_Relaxation_per_user` int(11) NOT NULL,
  `stat_mood` decimal(10,2) DEFAULT NULL,
  `stat_cause` decimal(10,2) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`stat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `timze_zone_update`
--

DROP TABLE IF EXISTS `timze_zone_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timze_zone_update` (
  `user_id` int(11) unsigned NOT NULL,
  `time_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tip_box_text`
--

DROP TABLE IF EXISTS `tip_box_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tip_box_text` (
  `tip_box_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tip_box_html` text,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`tip_box_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_activation_sms`
--

DROP TABLE IF EXISTS `user_activation_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activation_sms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `response` varchar(1000) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_activities`
--

DROP TABLE IF EXISTS `user_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activities` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT 'created_by',
  `friend_id` int(11) unsigned NOT NULL,
  `permission` char(10) DEFAULT NULL,
  `activity` text NOT NULL,
  `activity_id_for` int(11) unsigned DEFAULT NULL,
  `activity_type` varchar(30) DEFAULT NULL,
  `activity_action` varchar(30) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `serialize_activity` text NOT NULL,
  `activity_cat` enum('notification','stream','log') DEFAULT 'stream',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`friend_id`,`status`,`activity_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=5350 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_apps`
--

DROP TABLE IF EXISTS `user_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_apps` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `app_provider` varchar(100) DEFAULT NULL COMMENT 'google',
  `accessToken` varchar(1000) DEFAULT NULL,
  `expires` int(11) DEFAULT NULL,
  `refreshToken` varchar(100) DEFAULT NULL,
  `app_uid` varchar(200) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '1.Active 2. Need to Autherize again',
  `last_synced` timestamp NULL DEFAULT NULL,
  `syncing` tinyint(4) DEFAULT '0' COMMENT 'current syncing status 0 or 1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_apps_activities`
--

DROP TABLE IF EXISTS `user_apps_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_apps_activities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `app_provider` varchar(100) DEFAULT NULL COMMENT 'google',
  `activity_date` datetime DEFAULT NULL,
  `total_calories` decimal(10,5) DEFAULT NULL,
  `total_distance` decimal(20,10) DEFAULT NULL,
  `total_steps` decimal(10,5) DEFAULT NULL,
  `total_time` decimal(10,2) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `other_details` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_apps_profie`
--

DROP TABLE IF EXISTS `user_apps_profie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_apps_profie` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `app_uid` varchar(200) DEFAULT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `description` text,
  `imageUrl` varchar(2000) DEFAULT NULL,
  `app_provider` varchar(100) DEFAULT NULL,
  `publicProfileUrl` varchar(200) DEFAULT NULL,
  `other_details` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_badges`
--

DROP TABLE IF EXISTS `user_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_badges` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `badge_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `popup` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `badge_id` (`badge_id`,`user_id`,`status`,`popup`)
) ENGINE=InnoDB AUTO_INCREMENT=925 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge`
--

DROP TABLE IF EXISTS `user_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) unsigned NOT NULL,
  `parameter1` tinyint(4) DEFAULT NULL,
  `parameter2` tinyint(4) DEFAULT NULL,
  `mission_id` int(11) unsigned NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  `completed` enum('0') DEFAULT '0',
  `view_status` tinyint(2) DEFAULT '1',
  `reminders` varchar(255) DEFAULT NULL,
  `reminders_time` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`challenge_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=1328 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge_aq`
--

DROP TABLE IF EXISTS `user_challenge_aq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge_aq` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `user_challenge_id` int(11) DEFAULT NULL,
  `aq_id` tinyint(2) DEFAULT NULL,
  `aq_answer` tinyint(2) DEFAULT NULL,
  `mission_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge_reminders`
--

DROP TABLE IF EXISTS `user_challenge_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge_reminders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_cha_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) unsigned NOT NULL,
  `remind_on` datetime NOT NULL,
  `reminded` tinyint(4) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1104 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge_statistics`
--

DROP TABLE IF EXISTS `user_challenge_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge_statistics` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) NOT NULL,
  `total_yes` int(5) DEFAULT '0',
  `hm_total_yes` int(5) DEFAULT '0',
  `total_no` int(5) DEFAULT '0',
  `hm_total_no` int(5) DEFAULT '0',
  `total_span_no` int(5) DEFAULT '0',
  `hm_total_span_no` int(5) DEFAULT '0',
  `total_gap_temp` tinyint(5) DEFAULT '0',
  `last_update_date` date DEFAULT NULL,
  `score` decimal(10,2) DEFAULT '0.00',
  `habit_t` int(4) DEFAULT '0',
  `total_taken` int(5) DEFAULT '0',
  `update_same_day` int(5) DEFAULT '0',
  `streak` varchar(250) DEFAULT NULL,
  `streak_temp` tinyint(4) DEFAULT '0',
  `target_popup` varchar(50) DEFAULT NULL,
  `achieved` enum('0','1') DEFAULT '0',
  `last_yes_date` date DEFAULT NULL,
  `consistency` decimal(10,2) DEFAULT '0.00',
  `commitment` decimal(10,2) DEFAULT '0.00',
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=620 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge_statistics_copy`
--

DROP TABLE IF EXISTS `user_challenge_statistics_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge_statistics_copy` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) NOT NULL,
  `total_yes` int(5) DEFAULT '0',
  `hm_total_yes` int(5) DEFAULT '0',
  `total_no` int(5) DEFAULT '0',
  `hm_total_no` int(5) DEFAULT '0',
  `total_span_no` int(5) DEFAULT '0',
  `hm_total_span_no` int(5) DEFAULT '0',
  `total_gap_temp` tinyint(5) DEFAULT '0',
  `last_update_date` datetime DEFAULT NULL,
  `score` decimal(10,2) DEFAULT '0.00',
  `total_taken` int(5) DEFAULT '0',
  `update_same_day` int(5) DEFAULT '0',
  `streak` varchar(250) DEFAULT NULL,
  `streak_temp` tinyint(4) DEFAULT '0',
  `commitment_level` int(5) DEFAULT NULL,
  `target_popup` varchar(50) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge_targets`
--

DROP TABLE IF EXISTS `user_challenge_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge_targets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) NOT NULL,
  `target_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_challenge_updates`
--

DROP TABLE IF EXISTS `user_challenge_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_challenge_updates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_challenge_id` int(11) unsigned NOT NULL,
  `mission_id` int(11) unsigned NOT NULL,
  `challenge_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `update_status` enum('yes','no') NOT NULL,
  `updated_for` date NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5667 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_contact_info`
--

DROP TABLE IF EXISTS `user_contact_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_contact_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `display_name` varchar(25) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `alternate_email` varchar(100) DEFAULT NULL,
  `mobile` varchar(14) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `country_id` int(4) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `dob` date NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `birthday_reminder` tinyint(1) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `profile_image` varchar(100) CHARACTER SET latin1 NOT NULL,
  `original_image` varchar(100) NOT NULL,
  `race_id` tinyint(2) DEFAULT NULL,
  `csv_file_name` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`first_name`,`last_name`,`profile_image`,`original_image`)
) ENGINE=InnoDB AUTO_INCREMENT=3505 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_dares`
--

DROP TABLE IF EXISTS `user_dares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_dares` (
  `dare_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dare_user_id` int(11) unsigned DEFAULT NULL,
  `dare_freind_id` int(11) unsigned DEFAULT NULL,
  `dare_text` varchar(100) DEFAULT NULL,
  `dare_pride` varchar(100) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `dare_status` enum('cr','ac','rj','cl','cla','clr','cll') DEFAULT NULL,
  `claimed_by` int(11) unsigned DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT '1',
  `my_dare_id` int(11) DEFAULT NULL,
  `my_pride_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `admin_dare_id` int(11) DEFAULT NULL,
  `completed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dare_id`),
  KEY `dare_user_id` (`dare_user_id`,`dare_freind_id`,`dare_status`,`claimed_by`,`is_public`,`admin_dare_id`,`completed`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_dares_cheers`
--

DROP TABLE IF EXISTS `user_dares_cheers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_dares_cheers` (
  `cheers_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dare_id` int(11) unsigned NOT NULL,
  `created_by` int(11) unsigned NOT NULL,
  `cheers_user_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`cheers_id`),
  KEY `dare_id` (`dare_id`,`cheers_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_friends`
--

DROP TABLE IF EXISTS `user_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_friends` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `initiator_user_id` int(11) unsigned NOT NULL,
  `friend_user_id` int(11) unsigned NOT NULL,
  `is_confirmed` tinyint(1) DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `modfied_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `initiator_user_id` (`initiator_user_id`,`friend_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=691 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_gcm`
--

DROP TABLE IF EXISTS `user_gcm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_gcm` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `gcm` varchar(500) DEFAULT NULL,
  `os` varchar(20) DEFAULT NULL,
  `status` tinyint(3) DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `failed_attempts` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gcm` (`gcm`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_health_tracking`
--

DROP TABLE IF EXISTS `user_health_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_health_tracking` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `waist` float DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=357 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_login_attempts`
--

DROP TABLE IF EXISTS `user_login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `login_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3196 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_meta`
--

DROP TABLE IF EXISTS `user_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `meta_key` varchar(30) DEFAULT NULL,
  `meta_value` text,
  `created_on` datetime DEFAULT NULL,
  `completed` tinyint(4) DEFAULT '0',
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8670 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_mission`
--

DROP TABLE IF EXISTS `user_mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_mission` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mis_name` varchar(25) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `completed` tinyint(2) DEFAULT '0',
  `completed_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`completed`)
) ENGINE=InnoDB AUTO_INCREMENT=536 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_mood`
--

DROP TABLE IF EXISTS `user_mood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_mood` (
  `user_mood_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mood_id` int(11) DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `moode_type` enum('good','bad') DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`user_mood_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perms`
--

DROP TABLE IF EXISTS `user_perms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `perm_id` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_personal_details`
--

DROP TABLE IF EXISTS `user_personal_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_personal_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned DEFAULT NULL,
  `height` float DEFAULT NULL,
  `fillaccurate` enum('0','1') DEFAULT NULL,
  `sbp` int(10) DEFAULT NULL,
  `dbp` int(10) DEFAULT NULL,
  `smoking` varchar(20) DEFAULT NULL,
  `diabetic` varchar(10) DEFAULT NULL,
  `parental_diabetes` varchar(10) DEFAULT NULL,
  `parental_hypertension` varchar(10) DEFAULT NULL,
  `physical_activity` varchar(10) DEFAULT NULL,
  `alcohol` varchar(15) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_play_time`
--

DROP TABLE IF EXISTS `user_play_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_play_time` (
  `play_time_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `play_time_for` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `played_time` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`play_time_id`),
  KEY `user_id` (`user_id`,`status`,`played_time`)
) ENGINE=InnoDB AUTO_INCREMENT=711 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_points`
--

DROP TABLE IF EXISTS `user_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_points` (
  `user_points_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `point_id_for` int(11) NOT NULL,
  `point_id` int(11) NOT NULL,
  `corp_cause_id` int(11) DEFAULT NULL,
  `actual_points` int(11) NOT NULL,
  `pledge` int(4) DEFAULT NULL,
  `redeem_points` decimal(8,2) NOT NULL DEFAULT '0.00',
  `cause_points` decimal(8,2) DEFAULT '0.00',
  `parent_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `point_status` tinyint(2) NOT NULL DEFAULT '1',
  `played_time` decimal(10,2) NOT NULL,
  PRIMARY KEY (`user_points_id`),
  KEY `user_id` (`user_id`,`corp_cause_id`,`actual_points`,`redeem_points`,`cause_points`,`point_status`)
) ENGINE=InnoDB AUTO_INCREMENT=8983 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_resilience`
--

DROP TABLE IF EXISTS `user_resilience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_resilience` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `power_up_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=576 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_rewards`
--

DROP TABLE IF EXISTS `user_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_rewards` (
  `ur_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `reward_id` int(11) NOT NULL,
  `points_taken` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `booking_status` enum('claimed','awarded','cancelled') NOT NULL DEFAULT 'awarded',
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`ur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `user_id` int(11) unsigned NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `forgot_password_hash` varchar(100) DEFAULT NULL,
  `forgot_password_time` datetime DEFAULT NULL,
  `remember_me_hash` varchar(100) DEFAULT NULL,
  `verify_hash` varchar(100) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `time_zone` varchar(30) DEFAULT NULL,
  `language` varchar(20) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '3',
  `created_on` datetime DEFAULT NULL,
  `idhash` varchar(200) DEFAULT NULL,
  `points_group_id` int(5) NOT NULL DEFAULT '1',
  `activated_on` datetime NOT NULL,
  `old_email` varchar(200) NOT NULL,
  `mobile_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `email` (`email`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3505 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `work_with_us`
--

DROP TABLE IF EXISTS `work_with_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_with_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `resume` varchar(50) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `year_didyouknow`
--

DROP TABLE IF EXISTS `year_didyouknow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `year_didyouknow` (
  `id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `year` int(4) NOT NULL,
  `year_info` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yogi_panda_says`
--

DROP TABLE IF EXISTS `yogi_panda_says`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yogi_panda_says` (
  `says_id` int(11) NOT NULL AUTO_INCREMENT,
  `says_name` varchar(255) NOT NULL,
  `says_link` varchar(255) NOT NULL,
  `says_status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`says_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-29 15:58:35
