INSERT INTO `roles` (`id`, `role_name`) VALUES (1,'Administrators'),(2,'User'),(3,'Corporate Admin'),(4,'Corporate HR'),(5,'Developers');
