INSERT INTO `resilience` (`id`, `name`, `image`, `status`) VALUES (1,'Physical','physical.png',1),(2,'Mental','mental.png',1),(3,'Emotional','emotional.png',1),(4,'Social','social.png',1);
