INSERT INTO `modules` (`id`, `name`, `display_name`, `status`) VALUES (1,'invite_friends','Invite Friends',1),(2,'cause','Cause',1);
